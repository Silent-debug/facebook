document.addEventListener('DOMContentLoaded', function() {
  const selectedAccount = localStorage.getItem('selectedResult');
  document.getElementById('selectedAccount').textContent = selectedAccount;
});

document.getElementById('getCodeButton').addEventListener('click', function() {
  const timer = document.getElementById('timer');
  let time = 300;
  timer.classList.remove('hidden');
  
  const interval = setInterval(() => {
    const minutes = Math.floor(time / 60);
    const seconds = time % 60;
    timer.textContent = `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
    time--;

    if (time < 0) {
      clearInterval(interval);
      timer.textContent = 'Time expired!';
    }
  }, 1000);
});

document.getElementById('enterButton').addEventListener('click', function() {
  window.location.href = 'success.html';
});
